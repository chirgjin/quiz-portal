import React, { Component } from 'react';
import './../css/App.css';

class App extends Component {
  render() {
    return (
      <div className="App">
        Hello
      </div>
    );
  }
}

export default App;
