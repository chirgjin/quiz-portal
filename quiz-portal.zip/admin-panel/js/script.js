const json = {
    
}

$(document).ready(function() {

});
