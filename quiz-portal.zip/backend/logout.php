<?php
/**
 * Logout.php
 */

require_once __DIR__ . "/check.php";

SESSION::destroy();